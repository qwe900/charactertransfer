local private = CHDMP.private

function private.GetMACData()
    local ret = {}

    if GetNumCompanions and GetCompanionInfo then
        for i = 1, GetNumCompanions("MOUNT") do
            local _, _, spellId = GetCompanionInfo("MOUNT", i)
            ret["M:" .. i] = spellId
        end
        for i = 1, GetNumCompanions("CRITTER") do
            local _, _, spellId = GetCompanionInfo("CRITTER", i)
            ret["C:" .. i] = spellId
        end
    end

    private.ILog("Mounts & Critters DONE...")
    return ret
end
