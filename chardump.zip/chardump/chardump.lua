-- Keep reference to original JSON encoder and clear global json table
local myJSON = json
json = {}

CHDMP = CHDMP or {}
local private = {}
private.dmp = {}

local dumpFrame = nil

--------------------------------------------------
-- Playtime handling
--------------------------------------------------

local totalTimePlayed      = 0
local timePlayedThisLevel  = 0
local playerInfoReady      = false

local playtimeFrame = CreateFrame("Frame")
playtimeFrame:RegisterEvent("TIME_PLAYED_MSG")

playtimeFrame:SetScript("OnEvent", function(_, _, total, thisLevel)
	totalTimePlayed     = total
	timePlayedThisLevel = thisLevel
	playerInfoReady     = true
end)

local function GetPlayTime()
	if playerInfoReady then
		return totalTimePlayed
	end
	return 0
end

--------------------------------------------------
-- Logging helpers
--------------------------------------------------

function private.Log(str)
	print("\124c0080C0FF  " .. (str or "") .. "\124r")
end

function private.ILog(str)
	print("\124c0080FF80" .. (str or "") .. "\124r")
end

function private.ErrLog(err)
	private.errlog = private.errlog or ""
	private.errlog = private.errlog .. "err=" .. b64_enc(err or "nil") .. "\n"
	print("\124c00FF0000" .. (err or "nil") .. "\124r")
end

function private.trycall(func, errHandler)
	local ok, result = xpcall(func, errHandler)
	if ok then
		return result
	end
	return ok
end

local function CountKeys(tbl)
	local c = 0
	if tbl then
		for _ in pairs(tbl) do
			c = c + 1
		end
	end
	return c
end

--------------------------------------------------
-- Global / client info
--------------------------------------------------

function private.GetGlobalInfo()
	local retTbl      = {}
	retTbl.locale     = GetLocale()
	retTbl.realm      = GetRealmName()
	retTbl.realmlist  = GetCVar("realmList")
	local _, build    = GetBuildInfo()
	retTbl.clientbuild = build
	return retTbl
end

--------------------------------------------------
-- Basic player stats
--------------------------------------------------

function private.GetPlayerStats()
	local stats = {}

	stats.health = UnitHealthMax("player")

	local base
	base = select(1, UnitStat("player", 1)) -- Strength
	stats.strength = base

	base = select(1, UnitStat("player", 2)) -- Agility
	stats.agility = base

	base = select(1, UnitStat("player", 3)) -- Stamina
	stats.stamina = base

	base = select(1, UnitStat("player", 4)) -- Intellect
	stats.intellect = base

	base = select(1, UnitStat("player", 5)) -- Spirit
	stats.spirit = base

	return stats
end

function private.GetUnitInfo()
	local retTbl      = {}

	retTbl.name       = UnitName("player")
	local _, class    = UnitClass("player")
	retTbl.class      = class
	retTbl.level      = UnitLevel("player")
	local _, race     = UnitRace("player")
	retTbl.race       = race
	retTbl.gender     = UnitSex("player")

	local honorableKills = GetPVPLifetimeStats()
	retTbl.kills      = honorableKills
	retTbl.honor      = GetHonorCurrency()
	retTbl.arenapoints = GetArenaCurrency()
	retTbl.money      = GetMoney()
	retTbl.specs      = GetNumTalentGroups()
	retTbl.playtime   = GetPlayTime()

	return retTbl
end

--------------------------------------------------
-- Spell data
--------------------------------------------------

function private.GetSpellData()
    local retTbl = {}
    for i = 1, MAX_SKILLLINE_TABS do
        local name, _, _, offset, numSpells = GetSpellTabInfo(i);
        if not name then
            break;
        end
        for s = offset + 1, offset + numSpells do
            local spellInfo = GetSpellLink(s, BOOKTYPE_SPELL);
            if spellInfo ~= nil then
                for spellid in string.gmatch(GetSpellLink(s, BOOKTYPE_SPELL),".-Hspell:(%d+).*") do
                    retTbl[spellid] = i;
                end
            end
        end
    end
    private.ILog("Spells DONE...");
    return retTbl;
end

--------------------------------------------------
-- Currency data
--------------------------------------------------

function private.GetCurrencyData()
	local retTbl = {}

	for i = 1, GetCurrencyListSize() do
		local _, _, _, _, _, count, _, _, itemID = GetCurrencyListInfo(i)
		retTbl[i] = { C = count, I = itemID }
	end

	return retTbl
end

--------------------------------------------------
-- Mounts and critters
--------------------------------------------------

function private.GetMACData()
	local retTbl = {}

	for i = 1, GetNumCompanions("MOUNT") do
		local _, _, mountSpellId = GetCompanionInfo("MOUNT", i)
		retTbl["M:" .. i] = mountSpellId
	end

	for i = 1, GetNumCompanions("CRITTER") do
		local _, _, critterSpellId = GetCompanionInfo("CRITTER", i)
		retTbl["C:" .. i] = critterSpellId
	end

	private.ILog("Mounts & Critters DONE...")
	return retTbl
end

--------------------------------------------------
-- Achievement category data
--------------------------------------------------

function private.GetAchievementCategoryData()
    local achievements    = {}
    local numAchievements = GetCategoryNumAchievements(-1)

    for index = 1, numAchievements do
        local achievementID, _, points, completed,
        month, day, year, _, _, _, _, isGuildAch = GetAchievementInfo(-1, index)

        -- Überspringen, wenn NICHT completed
        if completed then
            local categoryID = GetAchievementCategory(achievementID)

            local timeStamp = 0
            if year and month and day and year > 0 then
                timeStamp = time({
                    year  = 2000 + year,
                    month = month,
                    day   = day
                }) or 0
            end

            local achievement = {
                id                 = achievementID,
                points             = points,
                completed          = 1,       -- IMMER 1, weil wir nur completed einfügen
                time               = timeStamp,
                isGuildAchievement = isGuildAch,
                category           = categoryID,
            }

            table.insert(achievements, achievement)
        end
    end

    return achievements
end


--------------------------------------------------
-- Quest completed data
--------------------------------------------------

function private.GetQuestCompletedData()
    local Questlist = {}
    local completedQuests = {}

    if GetQuestsCompleted then
        GetQuestsCompleted(Questlist) -- füllt Questlist[questID] = 1/true

        for questID, isCompleted in pairs(Questlist) do
            -- alles, was "wahr" ist, akzeptieren (3.3.5 gibt meist 1 zurück)
            if isCompleted then
                -- Quest-ID als WERT in eine Liste einfügen
                table.insert(completedQuests, questID)
            end
        end
    end

    return completedQuests
end



--------------------------------------------------
-- Statistics (nur IDs und Zahlen, ohne Namen)
--------------------------------------------------

function private.DumpPlayerStatistic()
	local playerStatistics = {}

	local categoryList = GetStatisticsCategoryList()
	for _, categoryId in pairs(categoryList) do
		local numStats = GetCategoryNumAchievements(categoryId)

		for i = 1, numStats do
			local statId = select(1, GetAchievementInfo(categoryId, i))
			local ok, quantity = pcall(GetStatistic, statId)

			if ok and quantity ~= nil then
				local stat = {
					id       = statId,
					quantity = tonumber(quantity) or 0,
					criteria = {},
				}

				local numCriteria = GetAchievementNumCriteria(statId)
				for j = 1, numCriteria do
					local _, _, completed, cQuantity,
					_, _, _, _, _, criteriaID =
						GetAchievementCriteriaInfo(statId, j)

					table.insert(stat.criteria, {
						id        = criteriaID,
						quantity  = tonumber(cQuantity) or 0,
						completed = completed and 1 or 0,
					})
				end

				table.insert(playerStatistics, stat)
			end
		end
	end

	return playerStatistics
end

--------------------------------------------------
-- Inventory / item data
--------------------------------------------------

local function ExtractItemAndEnchant(itemLink)
	if not itemLink then return nil, nil end
	local itemId, enchantId = itemLink:match("item:(%d+):(%d+)")
	return tonumber(itemId), tonumber(enchantId)
end

local function ExtractGems(itemLink)
	local g1, g2, g3 = 0, 0, 0

	local gem1name, gem1Link = GetItemGem(itemLink, 1)
	if gem1name and gem1Link then
		g1 = tonumber(gem1Link:match("item:(%d+)")) or 0
	end

	local gem2name, gem2Link = GetItemGem(itemLink, 2)
	if gem2name and gem2Link then
		g2 = tonumber(gem2Link:match("item:(%d+)")) or 0
	end

	local gem3name, gem3Link = GetItemGem(itemLink, 3)
	if gem3name and gem3Link then
		g3 = tonumber(gem3Link:match("item:(%d+)")) or 0
	end

	return g1, g2, g3
end






function private.GetIData()
	local retTbl = {}

	-- Equipped items
	for slot = 0, 135 do
		local itemLink = GetInventoryItemLink("player", slot)
		if itemLink then
			local equipSlot = select(9, GetItemInfo(itemLink))
			local quality   = select(3, GetItemInfo(itemLink))
			local count     = (equipSlot == "INVTYPE_BAG") and 1 or GetInventoryItemCount("player", slot)

			local itemId, enchantId = ExtractItemAndEnchant(itemLink)
			local g1, g2, g3         = ExtractGems(itemLink)

			retTbl["0000:" .. slot] = {
				I       = itemId,
				C       = count,
				E       = enchantId,
				G1      = g1,
				G2      = g2,
				G3      = g3,
				Q = quality,
			}
		end
	end

	-- Bags
	for bag = 0, 11 do
		local numSlots = GetContainerNumSlots(bag)
		for slot = 1, numSlots do
			local itemLink = GetContainerItemLink(bag, slot)
			if itemLink then
				local _, count = GetContainerItemInfo(bag, slot)
				local quality  = select(3, GetItemInfo(itemLink))
				local itemId, enchantId = ExtractItemAndEnchant(itemLink)
				local g1, g2, g3        = ExtractGems(itemLink)

				local prefix = bag + 1000
				retTbl[prefix .. ":" .. slot] = {
					I       = itemId,
					C       = count,
					E       = enchantId,
					G1      = g1,
					G2      = g2,
					G3      = g3,
					Q = quality,
				}
			end
		end
	end

	private.ILog("Inventory DONE...")
	return retTbl
end

--------------------------------------------------
-- Reputation data (Whitelist + GetFactionInfoByID, mit ID im Objekt)
--------------------------------------------------

local REPUTATION_IDS = {
    21, 47, 54, 59, 67, 68, 69, 70, 72, 76, 81,
    87, 92, 93, 169, 270, 349, 369, 469, 470,
    509, 510, 529, 530, 576, 577, 589, 609,
    729, 730, 749, 809, 889, 890, 909, 910,
    911, 922, 930, 932, 933, 934, 935, 941,
    942, 946, 947, 967, 970, 978,
    989, 990, 1011, 1012, 1015, 1031, 1038,
    1050, 1052, 1064, 1067, 1068, 1073, 1077,
    1082, 1085, 1090, 1091, 1094, 1098, 1104,
    1105, 1106, 1119, 1124, 1156

}

--------------------------------------------------
-- Reputation data (DB-ready, standing != 0)
--------------------------------------------------

function private.GetRepData()
    local retTbl = {}

    if type(GetFactionInfoByID) ~= "function" then
        private.ErrLog("GetFactionInfoByID not available on this client")
        return retTbl
    end

    for _, factionID in ipairs(REPUTATION_IDS) do
        local name, description, standingID,
        bottomValue, topValue, earnedValue,
        atWarWith, canToggleAtWar, isHeader =
        GetFactionInfoByID(factionID)

        -- Nur echte Fraktionen mit Standing
        if name and not isHeader and earnedValue and earnedValue ~= 0 then

            local flags = 0

            -- immer sichtbar
            flags = bit.bor(flags, 1) -- FACTION_FLAG_VISIBLE

            -- at war
            if canToggleAtWar and atWarWith then
                flags = bit.bor(flags, 2) -- FACTION_FLAG_AT_WAR
            end

            -- peace forced
            if not canToggleAtWar then
                flags = bit.bor(flags, 16) -- FACTION_FLAG_PEACE_FORCED
            end

            table.insert(retTbl, {
                faction  = factionID,
                standing = earnedValue,
                flags    = flags,
            })
        end
    end

    private.ILog("Reputations DONE (" .. #retTbl .. " entries)")
    return retTbl
end


--------------------------------------------------
-- Skills / professions
--------------------------------------------------

local professionSpellIdsList = {
	2259, 2018, 7411, 4036, 2366, 45357, 25229, 2108, 8613, 3908, 45542, 65293, 51296, 762,
}

function GetWeaponSKillNames()
	local numCriteria     = GetAchievementNumCriteria(705)
	local achievementData = {}

	for i = 1, numCriteria do
		local criteriaString, criteriaType, completed, quantity,
		requiredQuantity, characterName, flags, assetID,
		quantityString, criteriaID, eligible =
			GetAchievementCriteriaInfo(705, i)

		achievementData[i] = {
			criteriaString   = criteriaString,
			criteriaType     = criteriaType,
			completed        = completed,
			quantity         = quantity,
			requiredQuantity = requiredQuantity,
			characterName    = characterName,
			flags            = flags,
			assetID          = assetID,
			quantityString   = quantityString,
			criteriaID       = criteriaID,
			eligible         = eligible,
		}
	end

	return achievementData
end

function private.GetSkillData()
    local retTbl = {}
    local WeaponSKillNames = GetWeaponSKillNames()

    -- Build professionSpellIds at runtime to avoid tainting
    local professionSpellIds = {}
    for _, spellId in ipairs(professionSpellIdsList) do
        professionSpellIds[spellId] = GetSpellInfo(spellId)
    end


    for i = 1, GetNumSkillLines() do
        local skillName, isHeader, _, skillRank, _, _, skillMaxRank, _, _, _, _, _, _ = GetSkillLineInfo(i)
        if not isHeader then
            retTbl[i] = {
                 ["N"] = skillName,
                ["C"] = skillRank,
                 ["M"] = skillMaxRank,
                -- ["S"] = nil,
               -- ["P"] = nil
            }

            for _, achievement in pairs(WeaponSKillNames) do
                if skillName == achievement.criteriaString then
                    retTbl[i]["Skill"] = achievement.assetID
                    break
                end
            end

            -- Check if skillName is in professionSpellIds
            for spellId, professionName in pairs(professionSpellIds) do
                if skillName == professionName then
                    retTbl[i]["S"] = spellId
                    break
                end
            end
        end
    end


    return retTbl;
end

--------------------------------------------------
-- Talents
--------------------------------------------------

function private.GetTalentTree()
	local talentData = {}

	for specIndex = 1, GetNumTalentGroups() do
		talentData[specIndex] = {}

		for tabIndex = 1, GetNumTalentTabs() do
			local tabName, tabTexture =
				GetTalentTabInfo(tabIndex, false, false, specIndex)

			local tabEntry = {
				name    = tabName,
				icon    = tabTexture and tabTexture:match("Interface\\Icons\\(.+)"),
				talents = {},
			}

			for talentIndex = 1, GetNumTalents(tabIndex) do
				local name, icon, _, _, currentRank, maxRank =
					GetTalentInfo(tabIndex, talentIndex, false, false, specIndex)

				local talentLink = GetTalentLink(tabIndex, talentIndex)
				local talentID   = talentLink and tonumber(talentLink:match("talent:(%d+)"))

				tabEntry.talents[talentIndex] = {
					name        = name,
					icon        = icon and icon:match("Interface\\Icons\\(.+)"),
					currentRank = currentRank,
					maxRank     = maxRank,
					tab         = tabIndex,
					talent      = talentIndex,
					talentID    = talentID,
				}
			end

			talentData[specIndex][tabIndex] = tabEntry
		end
	end

	return talentData
end

--------------------------------------------------
-- Glyphs
--------------------------------------------------

function private.GetGlyphData()
	local retTbl = {}

	for specIndex = 1, GetNumTalentGroups() do
		retTbl[specIndex] = {}

		for slotIndex = 1, 6 do
			local enabled, glyphType, glyphSpell = GetGlyphSocketInfo(slotIndex, specIndex)
			local glyphID = 0
			local link = GetGlyphLink(slotIndex, specIndex)
			if link then
				local _, glyphID_str = link:match("Hglyph:(%d+):(%d+)")
				glyphID = glyphID_str and tonumber(glyphID_str) or 0
			end
			retTbl[specIndex][slotIndex] = {
				glyphID = glyphID,
				Type = glyphType,
				spell = glyphSpell
			}
		end
	end

	private.ILog("Glyphs DONE...")
	return retTbl
end

--------------------------------------------------
-- Save / Build dump
--------------------------------------------------

local function BuildDumpString()
-- innere Ebene = JSON -> B64
	local inner = b64_enc(myJSON.encode(private.dmp))
	-- äußere Ebene nochmal B64 (wie bei dir vorher)
	return b64_enc(inner)
end

function private.SaveCharData(data, key)
	private.ILog("Chardump DONE: SavedVariables (per character)")
	CHDMP_DATA = data
	CHDMP_KEY  = key
	CHDMP_VER  = GetAddOnMetadata("chardump", "Version")
end

--------------------------------------------------
-- Status-Ausgabe (/chardump status)
--------------------------------------------------

function private.Status()
	local name      = UnitName("player") or "Unknown"
	local realm     = GetRealmName() or "Unknown"
	local _, class  = UnitClass("player")
	local level     = UnitLevel("player") or 0

	private.ILog(string.format("Status für %s-%s (Lv%d %s)", name, realm, level, class or "?"))

	local hasSessionDump = private.dmp and next(private.dmp) ~= nil
	if hasSessionDump then
		local qCount   = CountKeys(private.dmp.quests)
		local invCount = private.dmp.inventory and CountKeys(private.dmp.inventory) or 0
		private.Log(string.format("Session-Dump im Speicher: Quests=%d, Inventory-Einträge=%d", qCount, invCount))
	else
		private.Log("Session-Dump im Speicher: keiner (nutze /chardump).")
	end

	local hasSaved = type(CHDMP_DATA) == "string" and type(CHDMP_KEY) == "string"
	if hasSaved then
		private.Log(string.format(
			"SavedVariables: DATA-Länge=%d, KEY-Länge=%d, VER=%s",
			#CHDMP_DATA, #CHDMP_KEY, tostring(CHDMP_VER)
		))
	else
		private.Log("SavedVariables: keine CHDMP_DATA / CHDMP_KEY gefunden.")
	end

	private.Log(
		"Dateipfad (per Character): WTF\\Account\\<Account>\\" ..
		realm .. "\\" .. name .. "\\SavedVariables\\chardump.lua"
	)
end

--------------------------------------------------
-- Tradeskill hook & helper (wie vorher)
--------------------------------------------------

function private.TradeSkillFrame_OnShow_Hook(frame)
	if private.done then
		return
	end

	if frame and frame.GetName and frame:GetName() == "TradeSkillFrame" then
		private.dmp.recipes = private.dmp.recipes or {}

		for i = 1, GetNumTradeSkills() do
			local link = GetTradeSkillRecipeLink(i)
			if link then
				local spellId = tonumber(link:match("enchant:(%d+)"))
				if spellId then
					private.dmp.recipes[spellId] = spellId
				end
			end
		end

		print("Profession scanned!")

		for i = 1, 8 do
			local button = _G["TradeSkillSkill" .. i]
			if button then
				button:SetScript("OnClick", TradeSkillSkillButton_OnClick)
			end
		end

		local isLinked = IsTradeSkillLinked()
		if not isLinked then
			local link = GetTradeSkillListLink()
			if link then
				local skillname = link:match("%[(.-)%]")
				private.dmp.skilllink = private.dmp.skilllink or {}
				private.dmp.skilllink[skillname] = link
				print("Chardump: TradeSkillFrame_Show", skillname, link)
			end
		end
	end
end

function TradeSkillSkillButton_OnClick(self, button)
	if button ~= "LeftButton" then
		return
	end

	if IsShiftKeyDown() then
		if ChatEdit_GetActiveWindow() then
			ChatEdit_InsertLink(GetTradeSkillRecipeLink(self:GetID()))
		else
			DressUpItemLink(GetTradeSkillRecipeLink(self:GetID()))
		end
	elseif IsControlKeyDown() then
		TradeSkillFrame_LoadUI()
		if TradeSkillFrame_DropDown:IsVisible() then
			HideDropDownMenu(1)
		else
			ShowDropDownMenu(1, nil, TradeSkillFrame_DropDown,
				"TradeSkillFrame", TradeSkillFrame:GetWidth(), 0)
		end
	else
		TradeSkillFrame_SetSelection(self:GetID())
		TradeSkillFrame_Update()
	end
end

hooksecurefunc(_G, "ShowUIPanel", private.TradeSkillFrame_OnShow_Hook)

--------------------------------------------------
-- GUI: Hauptfenster mit Progressbar + Debug-Button
--------------------------------------------------

private.steps = {}
private.currentStep = 0
private.totalSteps = 0
private.cancelRequested = false
private.prepareStart = nil

local function UpdateProgressUI(label)
	if not dumpFrame then return end
	if label then
		dumpFrame.statusText:SetText(label)
	end
	if private.totalSteps > 0 then
		local value = (private.currentStep / private.totalSteps) * 100
		dumpFrame.progress:SetValue(value)
	else
		dumpFrame.progress:SetValue(0)
	end
end

function private.CreateMainFrame()
	if dumpFrame then return end

	local f = CreateFrame("Frame", "CHDMP_MainFrame", UIParent)
	f:SetSize(400, 170)
	f:SetPoint("CENTER")
	f:SetFrameStrata("DIALOG")
	f:SetBackdrop({
		bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
		edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
		tile     = true, tileSize = 32, edgeSize = 32,
		insets   = { left = 11, right = 12, top = 12, bottom = 11 }
	})

	f:SetMovable(true)
	f:EnableMouse(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", f.StopMovingOrSizing)

	local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	title:SetPoint("TOP", 0, -16)
	title:SetText("Character Dumper")

	local text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	text:SetPoint("TOP", title, "BOTTOM", 0, -10)
	text:SetText("Diesen Charakter jetzt dumpen?")

	local statusText = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	statusText:SetPoint("TOP", text, "BOTTOM", 0, -10)
	statusText:SetText("Bereit.")

	local bar = CreateFrame("StatusBar", nil, f)
	bar:SetSize(280, 18)
	bar:SetPoint("TOP", statusText, "BOTTOM", 0, -10)
	bar:SetStatusBarTexture("Interface\\TARGETINGFRAME\\UI-StatusBar")
	bar:SetMinMaxValues(0, 100)
	bar:SetValue(0)

	local barBG = bar:CreateTexture(nil, "BACKGROUND")
	barBG:SetAllPoints(true)
	barBG:SetTexture(0, 0, 0, 0.5)

	-- Debug-Button (Status anzeigen)
	local dbg = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	dbg:SetSize(80, 22)
	dbg:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 20, 15)
	dbg:SetText("Debug")
	dbg:SetScript("OnClick", function()
		private.Status()
	end)

	local yes = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	yes:SetSize(80, 22)
	yes:SetPoint("BOTTOMRIGHT", f, "BOTTOM", -5, 15)
	yes:SetText("Ja")

	local no = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	no:SetSize(80, 22)
	no:SetPoint("LEFT", yes, "RIGHT", 10, 0)
	no:SetText("Nein")
	no:SetScript("OnClick", function() f:Hide() end)

	f.title        = title
	f.text         = text
	f.statusText   = statusText
	f.progress     = bar
	f.yesButton    = yes
	f.noButton     = no
	f.debugButton  = dbg

	dumpFrame = f
end

--------------------------------------------------
-- Step-Logik für Progressbar
--------------------------------------------------

local function Step_Prepare()
	if not private.prepareStart then
		-- Build professionSpellIds at runtime to avoid tainting
		local professionSpellIds = {}
		for _, spellId in ipairs(professionSpellIdsList) do
			professionSpellIds[spellId] = GetSpellInfo(spellId)
		end
		-- Special case for German Fishing override
		if GetLocale() == "deDE" then
			professionSpellIds[356] = GetSpellInfo(7620)
		end

		for _, spellName in pairs(professionSpellIds) do
			if spellName then
				CastSpellByName(spellName)
			end
		end

		if QueryQuestsCompleted then
			QueryQuestsCompleted()
		end
		if not playerInfoReady then
			RequestTimePlayed()
		end

		private.prepareStart = GetTime()
		UpdateProgressUI("Warte auf Serverdaten (Quests/Spielzeit)...")
		return false
	end

	local elapsed = GetTime() - private.prepareStart
	if (playerInfoReady or elapsed > 2) and elapsed > 3 then
		return true
	end

	return false
end

local function safeCallStore(field, func)
	if type(func) ~= "function" then
		private.ErrLog("Missing step function for field '" .. tostring(field) .. "'")
		private.dmp[field] = {}
		return true
	end

	private.dmp[field] = private.trycall(func, private.ErrLog) or {}
	return true
end


local function Step_SaveFinal()
	local fullDump = BuildDumpString()
--	if not fullDump or #fullDump <= 64 then
--private.ErrLog("Dump too short or invalid")
		--return true
	--end

	local data = string.sub(fullDump, 1, -65)
	local key  = string.sub(fullDump, -64)

	private.SaveCharData(data, key)
	UpdateProgressUI("Fertig – Dump gespeichert.")
	if dumpFrame then
		dumpFrame.yesButton:Enable()
		dumpFrame.noButton:SetText("Schließen")
		dumpFrame.noButton:SetScript("OnClick", function() dumpFrame:Hide() end)
	end
	return true
end

function private.BuildSteps()
	private.steps = {
		{ label = "Vorbereitung (Berufe / Quests / Spielzeit)", func = Step_Prepare },
		{ label = "Spieler-Stats sammeln",           func = function() return safeCallStore("unitstats",   private.GetPlayerStats) end },
		{ label = "Client/Realm-Infos sammeln",      func = function() return safeCallStore("globalinfo",  private.GetGlobalInfo) end },
		{ label = "Charakter-Infos sammeln",         func = function() return safeCallStore("unitinfo",    private.GetUnitInfo) end },
		{ label = "Reputationen sammeln",           func = function() return safeCallStore("reputation",  private.GetRepData) end },
		{ label = "Skillnamen (Waffen) sammeln",    func = function() return safeCallStore("skillnames",  GetWeaponSKillNames) end },
		{ label = "Erfolge sammeln",                func = function() return safeCallStore("achiev",      private.GetAchievementCategoryData) end },
		{ label = "Glyphen sammeln",                func = function() return safeCallStore("glyphs",      private.GetGlyphData) end },
		{ label = "Mounts & Begleiter sammeln",     func = function() return safeCallStore("creature",    private.GetMACData) end },
		{ label = "Zauberbuch auslesen",            func = function() return safeCallStore("spells",      private.GetSpellData) end },
		{ label = "Talentbäume auslesen",           func = function() return safeCallStore("talents",     private.GetTalentTree) end },
		{ label = "Skills / Berufe sammeln",        func = function() return safeCallStore("skills",      private.GetSkillData) end },
		{ label = "Inventar & Taschen sammeln",     func = function() return safeCallStore("inventory",   private.GetIData) end },
		{ label = "Statistiken sammeln",            func = function() return safeCallStore("statistic",   private.DumpPlayerStatistic) end },
		{ label = "Währungen sammeln",              func = function() return safeCallStore("currency",    private.GetCurrencyData) end },
		{ label = "Quest-Abschlüsse sammeln",       func = function() return safeCallStore("questscompleted",      private.GetQuestCompletedData) end },
		{ label = "Dump bauen & speichern",         func = Step_SaveFinal },
	}

	private.currentStep     = 0
	private.totalSteps      = #private.steps
	private.cancelRequested = false
	private.prepareStart    = nil
end

function private.OnUpdateDump(self, elapsed)
	if private.cancelRequested then
		UpdateProgressUI("Dump abgebrochen.")
		self:SetScript("OnUpdate", nil)
		if dumpFrame then
			dumpFrame.yesButton:Enable()
			dumpFrame.noButton:SetText("Schließen")
			dumpFrame.noButton:SetScript("OnClick", function() dumpFrame:Hide() end)
		end
		return
	end

	local stepInfo = private.steps[private.currentStep + 1]
	if not stepInfo then
		self:SetScript("OnUpdate", nil)
		return
	end

	local label = stepInfo.label or ("Schritt " .. (private.currentStep + 1))
	local done = stepInfo.func()

	UpdateProgressUI(label)

	if done then
		private.currentStep = private.currentStep + 1
		if private.currentStep >= private.totalSteps then
			UpdateProgressUI("Dump abgeschlossen.")
			self:SetScript("OnUpdate", nil)
		end
	end
end

function private.StartDumpProcess()
	private.dmp = {}
	private.BuildSteps()

	if not dumpFrame then
		private.CreateMainFrame()
	end

	dumpFrame.yesButton:Disable()
	dumpFrame.noButton:SetText("Abbrechen")
	dumpFrame.noButton:SetScript("OnClick", function()
		private.cancelRequested = true
	end)

	dumpFrame.progress:SetValue(0)
	dumpFrame.statusText:SetText("Starte Dump...")
	dumpFrame:Show()

	dumpFrame:SetScript("OnUpdate", private.OnUpdateDump)
end

--------------------------------------------------
-- Slash command /chardump
--------------------------------------------------

SLASH_CHDMP1 = "/chardump"
SlashCmdList["CHDMP"] = function(msg)
	msg = msg or ""
	msg = msg:lower():match("^%s*(.-)%s*$") or ""

	if msg == "done" then
		private.done = true
		return
	elseif msg == "help" then
		private.Log("Usage: /chardump [status|help]")
		private.Log("  /chardump         - öffnet GUI und startet Dump nach Bestätigung")
		private.Log("  /chardump status  - zeigt Status/Infos zum aktuellen/saved Dump")
		return
	elseif msg == "status" then
		private.Status()
		return
	end

	private.CreateMainFrame()
	dumpFrame.yesButton:Enable()
	dumpFrame.noButton:SetText("Nein")
	dumpFrame.noButton:SetScript("OnClick", function() dumpFrame:Hide() end)
	dumpFrame.progress:SetValue(0)
	dumpFrame.statusText:SetText("Bereit.")
	dumpFrame:Show()

	dumpFrame.yesButton:SetScript("OnClick", function()
		private.StartDumpProcess()
	end)
end
