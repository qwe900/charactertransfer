
-----------------------------------------------------------------------------
-- Module declaration
-----------------------------------------------------------------------------
json = {}             -- Public namespace
local json_private = {}     -- Private namespace

-- Public constants
json.EMPTY_ARRAY={}
json.EMPTY_OBJECT={}

-- Public functions

-- Private functions
local encodeString
local isArray
local isEncodable

-----------------------------------------------------------------------------
-- PUBLIC FUNCTIONS
-----------------------------------------------------------------------------
--- Encodes an arbitrary Lua object / variable.
-- @param v The Lua object / variable to be JSON encoded.
-- @return String containing the JSON encoding in internal Lua string format (i.e. not unicode)
local function encode (v)
    -- Handle nil values
    if v==nil then
        return "null"
    end

    local vtype = type(v)

    -- Handle strings
    if vtype=='string' then
        return '"' .. json_private.encodeString(v) .. '"'	    -- Need to handle encoding in string
    end

    -- Handle booleans
    if vtype=='number' or vtype=='boolean' then
        return tostring(v)
    end

    -- Handle tables
    if vtype=='table' then
        local rval = {}
        -- Consider arrays separately
        local bArray, maxCount = isArray(v)
        if bArray then
            for i = 1,maxCount do
                table.insert(rval, encode(v[i]))
            end
        else	-- An object, not an array
            for i,j in pairs(v) do
                if isEncodable(i) and isEncodable(j) then
                    table.insert(rval, '"' .. json_private.encodeString(i) .. '":' .. encode(j))
                end
            end
        end
        if bArray then
            return '[' .. table.concat(rval,',') ..']'
        else
            return '{' .. table.concat(rval,',') .. '}'
        end
    end

    -- Handle json.null function
    if vtype=='function' and v==json.null then
        return 'null'
    end

    assert(false,'encode attempt to encode unsupported type ' .. vtype .. ':' .. tostring(v))
end


--- The null function allows one to specify a null value in an associative array (which is otherwise
-- discarded if you set the value with 'nil' in Lua. Simply set t = { first=json.null }
function json.null()
    return json.null -- so json.null() will also return null ;-)
end

json.encode = encode
-----------------------------------------------------------------------------
-- Internal, PRIVATE functions.
-- Following a Python-like convention, I have prefixed all these 'PRIVATE'
-- functions with an underscore.
-----------------------------------------------------------------------------









--- Encodes a string to be JSON-compatible.
-- This just involves back-quoting inverted commas, back-quotes and newlines, I think ;-)
-- @param s The string to return as a JSON encoded (i.e. backquoted string)
-- @return The string appropriately escaped.

local escapeList = {
    ['"']  = '\\"',
    ['\\'] = '\\\\',
    ['/']  = '\\/',
    ['\b'] = '\\b',
    ['\f'] = '\\f',
    ['\n'] = '\\n',
    ['\r'] = '\\r',
    ['\t'] = '\\t'
}

function json_private.encodeString(s)
    local s = tostring(s)
    return s:gsub(".", function(c) return escapeList[c] end) -- SoniEx2: 5.0 compat
end

-- Determines whether the given Lua type is an array or a table / dictionary.
-- We consider any table an array if it has indexes 1..n for its n items, and no
-- other data in the table.
-- I think this method is currently a little 'flaky', but can't think of a good way around it yet...
-- @param t The table to evaluate as an array
-- @return boolean, number True if the table can be represented as an array, false otherwise. If true,
-- the second returned value is the maximum
-- number of indexed elements in the array.
function isArray(t)
    -- Next we count all the elements, ensuring that any non-indexed elements are not-encodable
    -- (with the possible exception of 'n')
    if (t == json.EMPTY_ARRAY) then return true, 0 end
    if (t == json.EMPTY_OBJECT) then return false end

    local maxIndex = 0
    for k,v in pairs(t) do
        if (type(k)=='number' and math.floor(k)==k and 1<=k) then	-- k,v is an indexed pair
            if (not isEncodable(v)) then return false end	-- All array elements must be encodable
            maxIndex = math.max(maxIndex,k)
        else
            if (k=='n') then
                if v ~= (t.n or #t) then return false end  -- False if n does not hold the number of elements
            else -- Else of (k=='n')
                if isEncodable(v) then return false end
            end  -- End of (k~='n')
        end -- End of k,v not an indexed pair
    end  -- End of loop across all pairs
    return true, maxIndex
end

--- Determines whether the given Lua object / table / variable can be JSON encoded. The only
-- types that are JSON encodable are: string, boolean, number, nil, table and json.null.
-- In this implementation, all other types are ignored.
-- @param o The object to examine.
-- @return boolean True if the object should be JSON encoded, false if it should be ignored.
function isEncodable(o)
    local t = type(o)
    return (t=='string' or t=='boolean' or t=='number' or t=='nil' or t=='table') or
            (t=='function' and o==json.null)
end



